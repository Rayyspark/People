<?php
  	include_once('paginator.class.php'); 
  	include_once('./inc/Functions.php'); 
 	$People = new People();
    $PageCon = $People->GetPageCon();
    $Msg = ''; 

    $Limit = ( isset( $_GET['limit'] ) ) ? $_GET['limit'] : 5;
    $Page  = ( isset( $_GET['page'] ) ) ? $_GET['page'] : 1;
    $Links = ( isset( $_GET['links'] ) ) ? $_GET['links'] : 6;

    if ($Page < 1){
        $Page = 1;
    } 

    $Query = 'SELECT * FROM '.$PageTable;
    $Paginator  = new Paginator($PageCon, $Query);
    $Results = '';
    if ($Paginator->getData($Limit, $Page)) {
        $Results    = $Paginator->getData($Limit, $Page);
    }
    
?>