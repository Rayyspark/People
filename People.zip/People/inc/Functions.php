<?php 
class People{
	private $Con;
	//Initializing Database
	public function __construct(){
		$Server = 'localhost';
		$User = 'root';
		$Pword = '';
		$Db = 'people';
		
		$this->Con = @mysqli_connect($Server,$User,$Pword,$Db);
		if(!$this->Con){
			echo 'Unable to Load Database';
		} 
	}
	public function GetPageCon()
	{
		$User = 'root';
		$Pword = '';
		try {
		    return  new PDO('mysql:host=localhost;dbname=people', $User, $Pword);
		} catch (PDOException $e) {
		    print "Error!: " . $e->getMessage() . "<br/>";
		    die();
		}
	}
	//Getting connection
	public function GetCon(){
		return $this->Con;
	}
	//Closing connection
	public function CloseCon(){
		$DbClose = mysqli_close($this->Con);
		return $DbClose ;
	}
	public function RunQuery($DbCon,$Sql){
		$Rs = mysqli_query($DbCon,$Sql);
		return $Rs;
	}
	public function CleanData($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = strip_tags($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}
	#Checking Numeric data
	public function NumData($Data,$Name) {
	  $Data = ($Data);
		if(is_numeric($Data)){
			 return true;
		}else{
			$Msg ="<span class='text-danger'>Please enter numbers as $Name</span><br>";
		}
	}
	#Escape Function
	public function DbEscape($Cn,$Dt){
		$Dt= var_export( $Cn->real_escape_string($Dt),True);
		return $Dt;
	}

	#Encryption Function
	function Encrypt($data){
		$data= md5(sha1($data));
		return $data;
	}
	//Rnd Token
	Public function RndStr(){
		$RndNum1 = rand(10,500);
		$RndNum2 = rand(100,1000);
		$Key = rand(0,9);
		$Key1 = rand(0,9);
		//Array 
		$StrArr = array('A','B','C','D','E','F','G','H','I','J');
		$StrArr1 = array('j','i','h','g','f','e','d','c','b','a');
		$StrWrd = array('An','bY','Ic','dO','En','Fi','gO','He','iS','Ju');
		$Token = $this::Encrypt( $StrArr[$Key] . $RndNum1 . $StrArr1[$Key]. $RndNum2.  $StrWrd[$Key1] );

		$_SESSION['StrToken'] = $Token;
		Return $_SESSION['StrToken'];

	}
	#Encryption Function
	Public function GenToken(){
		$Data = $this::RndStr();
		
		return $Data;
	}
	#Decryption Function
	Public function CheckToken($Hashed){
		if ( $_SESSION['StrToken'] == $Hashed){
			return true;
		}else{
			return false;
		}
	}
	public function CurDate(){
		date_default_timezone_set('Africa/Lagos');
		$Date = date("d M,Y");
		return $Date;
	}
	public function Redirect($Us){
		if(isset($Us)){
			header('location: index.php');
		}
	}
	public function Redirect1($Part){
	?>
	<script type="text/javascript">
		window.location.href ='<?php echo $Part; ?>';
	</script>

	<?php 
	}

}
?>