<?php
$Home0 = '<li class="active"><a href="index.php">Home</a></li>
		<li ><a id="Log" href="#">Login</a></li>
		';
$Home1 = '<li class="active"><a href="index.php">Home</a></li>
		<li ><a href="AddPeople.php">Add People</a></li>
		<li ><a href="SearchPeople.php">Search People</a></li>
		<li ><a href="Logout.php">Logout</a></li>';

$Pple = '<li ><a href="index.php">Home</a></li>
		<li class="active"><a href="AddPeople.php">Add People</a></li>
		<li ><a href="SearchPeople.php">Search People</a></li>
		<li ><a href="Logout.php">Logout</a></li>';

$Sch = '<li ><a href="index.php">Home</a></li>
		<li ><a href="AddPeople.php">Add People</a></li>
		<li class="active" ><a href="SearchPeople.php">Search People</a></li>
		<li ><a href="Logout.php">Logout</a></li>';

$Edit = '<li ><a href="index.php">Home</a></li>
		<li ><a href="AddPeople.php">Add People</a></li>
		<li class="active" ><a href="EditPeople.php">Edit People</a></li>
		<li ><a href="SearchPeople.php">Search People</a></li>
		<li ><a href="Logout.php">Logout</a></li>';
								
?>                         