<?php
	if (!isset($_SESSION['Admin'])){
		$People->Redirect('index');
	}

?>