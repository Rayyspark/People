<!Doctype html>
<html>
<head>
	<meta charset="utf-8">
	<!--using bootstrap-->
	<link rel="stylesheet" type="text/css" 	href="./css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" 	href="./css/bootstrap-theme.min.css">
	<!--using Custom css-->
	<link rel="stylesheet" type="text/css" 	href="./css/CustomStyle.css">
	<link rel="stylesheet" type="text/css" 	href="./css/style.css">
	<script type="text/javascript" src="./js/load.js"></script>
	<title>
		<?php echo $Title;?>
	</title>
	<link rel="icon" type="favicon" href="" >
	
	<meta name="viewport" content="width=device-width; initial-scale=1.0">
	
</head>
<body>
    <div class="container">
        <div class="row">
            <header class="">
                <nav class="navbar navbar-inverse">
	                    <!--nav class="navbar navbar-default navbar-fixed-bottom">
	                    <nav class="navbar navbar-default navbar-fixed-top"-->
                   	<div class="container-fluid">
                         <!--group menu better view on mobile-->
                        <nav class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"  data-target="#NavBar-Collapse" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <h3 class="text-white">Welcome to People's Record</h3>
                        </nav>
                    </div>
                    <div class="collapse navbar-collapse" id="NavBar-Collapse">
                        <ul class="nav navbar-nav">
                            <?php 
                                //Displaying Menu 
                                include_once('Menu.php');
                                if(isset($_SESSION['Admin'])){
                                     echo $Home1;
                                }else if($Title =='Add People'){
                                     echo $Pple;  
                                }else if($Title =='Search People'){
                                    echo $Sch;
                                
                                }else if($Title =='Edit People'){
                                    echo $Edit;
                                }else{
                                    echo $Home0;
                                }
                            ?>
                        </ul>
                    </div>
                </nav>
            </header>
        </div>

