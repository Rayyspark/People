   
             <div class="row">
                <footer <?php echo ($Title == 'Search People' OR $Title == 'People') ? 'class="col-md-12 footer footer1 "':'class="col-md-12 footer"';?> >
                    <p>
                        &copy;  <?php echo (date('Y'));?>
                    </p>
                </footer>
            </div>
        </div> <!--end of Con--> 
	<script type="text/javascript" src="./js/jquery.min.js"></script>
	<script type="text/javascript" src="./js/bootstrap.min.js"></script>
   <!--using jquery for Modal--> 
    <script type="text/javascript">

        $(document).ready(function(){
            //showing modal
            $(document).on('click','#Log',function(event){
                $('#Title').text('Please enter Login data here');
                //displaying btns and modal form
                $('#LoginBtn').show(400);
                $('.msg').hide();
                $('#Msg0').hide();
                $('#Msg1').hide();
                $('#LoginBtn').prop('disabled',true);
               
                $('#MyModal').modal('show');
            });
            //closing modal
            $('.ModCloseBtn').click(function(){
                $('#MyModal').modal('hide');
            });
            //validating user data
            function CheckData() {
                var Name = $('#Uname').val();
                var Pword = $('#Pword').val();

                 $('#LoginBtn').prop('disabled',true);

                if (Name ==''){
                     $('#Msg0').show();
                }else{
                    $('#Msg0').hide();
                    if(Pword == ''){
                        $('#Msg1').show();
                    }else {
                      $('#Msg1').hide();
                      $('#LoginBtn').prop('disabled',false);
                    }
                }
                
            }
            //when in textbox
            $('#Username').keyup(CheckData);
            $('#Pword').keyup(CheckData);

           
        });
    </script>

</body>
</html>